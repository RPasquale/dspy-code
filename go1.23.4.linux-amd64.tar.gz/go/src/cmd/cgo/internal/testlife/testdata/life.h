// Copyright 2010 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

extern void Step(int, int, int *, int *);
extern void DoStep(int, int, int, int, int, int, int *, int *);
extern const int MYCONST;
